import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Family {

    private String name;
    private String age;
    private String birthday;
    private String password;
    private String id;

    public Family(String name, String age, String birthday, String password, String id) {
        this.name = name;
        this.age = age;
        this.birthday = birthday;
        this.password = password;
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAge() {
        return age;
    }

    public void setAge(String age) {
        this.age = age;
    }

    public String getBirthday() {
        return birthday;
    }

    public void setBirthday(String birthday) {
        this.birthday = birthday;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public void savingFamily() throws IOException {
        List<String> s= new ArrayList<>();

        FileInputStream fi=new FileInputStream("Family.txt");
        DataInputStream DI=new DataInputStream(fi);
        Scanner scan=new Scanner(DI);

        while(scan.hasNextLine()){
            while(scan.hasNextLine()){
                s.add(scan.nextLine());
            }
        }

        File user=new File("Family.txt");
        FileWriter PostWrite=new FileWriter(user);

        setName(name);
        setAge(age);
        setBirthday(birthday);
        setId(id);
        setPassword(password);



        for(int i=0;i<s.size();i++){
            PostWrite.append(s.get(i)+"\n");
        }

        PostWrite.append(getId()+"\n");
        PostWrite.append(getPassword()+"\n");
        PostWrite.append(getName()+"\n");
        PostWrite.append(getAge()+"\n");
        PostWrite.append(getBirthday()+"\n");


        fi.close();
        DI.close();
        PostWrite.close();

    }
}
