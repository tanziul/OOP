import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Scanner;

public class Main {

    public static void clearScreen(){
        try {
            if (System.getProperty("os.name").contains("Windows"))
                new ProcessBuilder("cmd", "/c", "cls").inheritIO().start().waitFor();
            else
                Runtime.getRuntime().exec("clear");
        } catch (IOException | InterruptedException ex) {}
    }


    static String space="\t\t\t\t\t\t";
    static int k;
    static Scanner scanner=new Scanner(System.in);

    public static void section() throws IOException {
        System.out.println(space+"--------------------------------------------------------------");
        System.out.print(space+"To go back home page click any key: ");
        scanner.next();
        firstPage();
    }


    public static void showItem() throws IOException {
        clearScreen();

        FileInputStream fi=new FileInputStream("item.txt");
        DataInputStream DI=new DataInputStream(fi);
        Scanner output=new Scanner(DI);

        int i=0;
        System.out.println("\n\n\n\n\n\n");
        System.out.println(space+"--------------------------------------------------------------");
        System.out.println(space+"----                        ALL ITEM                         ----");
        System.out.println(space+"--------------------------------------------------------------");
        while(output.hasNextLine()){
            System.out.println(space+"\t"+output.nextLine());

            i++;
        }


        fi.close();
        DI.close();
    }

    public static void addItem() throws IOException {
        clearScreen();
        System.out.println("\n\n\n\n\n\n");
        System.out.println(space+"--------------------------------------------------------------");
        System.out.println(space+"----                        ADD ITEM                         ----");
        System.out.println(space+"--------------------------------------------------------------");
        System.out.print(space+"Enter something to input: ");
        String food=scanner.next();


        List<String> s= new ArrayList<>();

        FileInputStream fi=new FileInputStream("item.txt");
        DataInputStream DI=new DataInputStream(fi);
        Scanner output=new Scanner(DI);

        while(output.hasNextLine()){
            while(output.hasNextLine()){
                s.add(output.nextLine());
            }
        }

        File user=new File("item.txt");
        FileWriter PostWrite=new FileWriter(user);



        for(int i=0;i<s.size();i++){
            PostWrite.append(s.get(i)+"\n");
        }

        PostWrite.append(food+"\n");


        fi.close();
        DI.close();
        PostWrite.close();


    }
    public static void removeItem() throws IOException {
        clearScreen();
        System.out.println("\n\n\n\n\n\n");
        System.out.println(space+"--------------------------------------------------------------");
        System.out.println(space+"----                          REMOVE ITEM                        ----");
        System.out.println(space+"--------------------------------------------------------------");
        System.out.print(space+"\t\tWhich item you want to remove: ");
        String item=scanner.next();

        List<String> s= new ArrayList<>();

        FileInputStream fi=new FileInputStream("item.txt");
        DataInputStream DI=new DataInputStream(fi);
        Scanner output=new Scanner(DI);

        while(output.hasNextLine()){
            while(output.hasNextLine()){
                s.add(output.nextLine());
            }
        }
        File user=new File("item.txt");
        FileWriter PostWrite=new FileWriter(user);

        for(int i=0;i<s.size();i++){
            if(s.get(i).equals(item)){
                s.remove(i);
            }
        }
        for(int i=0;i<s.size();i++){
            PostWrite.append(s.get(i)+"\n");
        }

        fi.close();
        DI.close();
        PostWrite.close();


    }

    public static void freeze() throws IOException {
        clearScreen();
        System.out.println("\n\n\n\n\n\n");
        System.out.println(space+"--------------------------------------------------------------");
        System.out.println(space+"----                         FREEZE                          ----");
        System.out.println(space+"--------------------------------------------------------------");
        System.out.println(space+"\t\t1. Add item");
        System.out.println(space+"\t\t2. Remove item ");
        System.out.println(space+"\t\t3. show Item");
        System.out.println(space+"\t\t4. Kitchen section");
        System.out.println(space+"--------------------------------------------------------------");
        System.out.print(space+"\tChoose an option: ");
        int option=scanner.nextInt();
        if(option==1){
            addItem();
            System.out.println(space+"--------------------------------------------------------------");
            System.out.print(space+"To go back previous page click any key: ");
            scanner.next();
            freeze();
        }
        else if(option==2){
            removeItem();
            System.out.println(space+"--------------------------------------------------------------");
            System.out.print(space+"To go back previous page click any key: ");
            scanner.next();
            freeze();

        }
        else if(option==3){
            showItem();
            System.out.println(space+"--------------------------------------------------------------");
            System.out.print(space+"To go back previous page click any key: ");
            scanner.next();
            freeze();
        }
        else if(option==4){
            kitchenAssistant();
        }
    }

    public static void makeRecipe() throws IOException {
        clearScreen();
        System.out.println("\n\n\n\n\n\n");
        System.out.println(space+"--------------------------------------------------------------");
        System.out.println(space+"----                      MAKE RECIPE                        ----");
        System.out.println(space+"--------------------------------------------------------------");
        System.out.print(space+"\t\tEnter a element name: ");
        String item=scanner.next().toLowerCase();
        String fishCurry="Fish curry with fresh vegetable";
        String egg="Egg fry";
        if(fishCurry.toLowerCase().contains(item)){
            System.out.println(space+"--------------------------------------------------------------");
            System.out.println(space+"\t\tYou can make "+fishCurry);
//            System.out.println(space+"--------------------------------------------------------------");
        }
        else if(egg.toLowerCase().contains(item)){
            System.out.println(space+"--------------------------------------------------------------");
            System.out.println(space+"\t\tYou can make "+egg);
//            System.out.println(space+"--------------------------------------------------------------");
        }

        System.out.println(space+"--------------------------------------------------------------");
        System.out.print(space+"To go back previous page click any key: ");
        scanner.next();
        clearScreen();
        kitchenAssistant();

    }


    public static void kitchenAssistant() throws IOException {
        clearScreen();
        System.out.println("\n\n\n\n\n\n");
        System.out.println(space+"--------------------------------------------------------------");
        System.out.println(space+"----                  Kitchen Section                        ----");
        System.out.println(space+"--------------------------------------------------------------");
        System.out.println(space+"\t\t1. Freeze");
        System.out.println(space+"\t\t2. Make recipe");
        System.out.println(space+"\t\t3. Previous page");
        System.out.println(space+"--------------------------------------------------------------");
        System.out.print(space+"\tChoose an option: ");
        int option=scanner.nextInt();
        if(option==1){
            clearScreen();
            freeze();
        }
        else if(option==2){
            clearScreen();
            makeRecipe();
        }
        else if(option==3){
            clearScreen();
            familyMemberPanel("2001");
        }

    }
    public static void createNote() throws IOException {
        clearScreen();
        System.out.println("\n\n\n\n\n\n");
        System.out.println(space+"--------------------------------------------------------------");
        System.out.println(space+"----                      CREATE NOTE                        ----");
        System.out.println(space+"--------------------------------------------------------------");
        System.out.print(space+"\t\tEnter a keyword: ");
        String keyword=scanner.next();
        System.out.print(space+"\t\tEnter note details: ");
        scanner.nextLine();
        String details=scanner.nextLine();

        List<String> s= new ArrayList<>();

        FileInputStream fi=new FileInputStream("Note.txt");
        DataInputStream DI=new DataInputStream(fi);
        Scanner output=new Scanner(DI);

        while(output.hasNextLine()){
            while(output.hasNextLine()){
                s.add(output.nextLine());
            }
        }

        File user=new File("Note.txt");
        FileWriter PostWrite=new FileWriter(user);



        for(int i=0;i<s.size();i++){
            PostWrite.append(s.get(i)+"\n");
        }

        PostWrite.append(keyword+"\n");
        PostWrite.append(details+"\n");

        fi.close();
        DI.close();
        PostWrite.close();

        System.out.println(space+"--------------------------------------------------------------");
        System.out.print(space+"\t\tTo go back previous page click any key: ");
        scanner.next();
        note();

    }
    public static void listKeyword() throws IOException {
        clearScreen();
        List<String> s=new ArrayList<>();
        FileInputStream fi=new FileInputStream("Note.txt");
        DataInputStream DI=new DataInputStream(fi);
        Scanner output=new Scanner(DI);

        int i=0;
        System.out.println("\n\n\n\n\n\n");
        System.out.println(space+"--------------------------------------------------------------");
        System.out.println(space+"----                       ALL KEYWORD                       ----");
        System.out.println(space+"--------------------------------------------------------------");
        while(output.hasNextLine()){
            s.add(output.nextLine());
            i++;
        }
        for (int j=0;j<s.size();j=j+2){
            System.out.println(space+"\t\t"+s.get(j)+" ");
        }


        fi.close();
        DI.close();
        System.out.println("\n\n"+space+"--------------------------------------------------------------");
        System.out.print(space+"To go back previous page click any key: ");
        scanner.next();
        note();
    }

    public static void searchNote(String keyword) throws IOException {
        clearScreen();
        List<String> s=new ArrayList<>();
        FileInputStream fi=new FileInputStream("Note.txt");
        DataInputStream DI=new DataInputStream(fi);
        Scanner output=new Scanner(DI);

        int i=0;
        System.out.println("\n\n\n\n\n\n");
        System.out.println(space+"--------------------------------------------------------------");
        System.out.println(space+"----                       SEARCH NOTE                       ----");
        System.out.println(space+"--------------------------------------------------------------");
        while(output.hasNextLine()){
            s.add(output.nextLine());
            i++;
        }
        for (int j=0;j<s.size();j=j+2){
            if(s.get(j).equals(keyword)){
                System.out.println(space+"\t\tKeyword: "+s.get(j));
                System.out.println(space+"\t\tNote: "+s.get(j+1));
            }
        }


        fi.close();
        DI.close();
        System.out.println("\n\n"+space+"--------------------------------------------------------------");
        System.out.print(space+"To go back previous page click any key: ");
        scanner.next();
        note();
    }
    public static void note() throws IOException {
        clearScreen();
        System.out.println("\n\n\n\n\n\n");
        System.out.println(space+"--------------------------------------------------------------");
        System.out.println(space+"----                           NOTE                         ----");
        System.out.println(space+"--------------------------------------------------------------");
        System.out.println(space+"\t\t1. Make a note");
        System.out.println(space+"\t\t2. List of keyword");
        System.out.println(space+"\t\t3. Searched by keyword");
        System.out.println(space+"\t\t4. Previous Page");
        System.out.println(space+"--------------------------------------------------------------");
        System.out.print(space+"\tChoose an option: ");
        int option=scanner.nextInt();
        if(option==1){
            createNote();
        }
        else if(option==2){
            listKeyword();
        }
        else if(option==3){
            clearScreen();
            System.out.println("\n\n\n\n\n\n");
            System.out.println(space+"--------------------------------------------------------------");
            System.out.println(space+"----                           NOTE                         ----");
            System.out.println(space+"--------------------------------------------------------------");
            System.out.print(space+"\t\tEnter a keyword to search: ");
            searchNote(scanner.next());
        }
        else if(option==4){
            familyMemberPanel("2001");
        }
    }
    public static void accountSection() throws IOException {
        clearScreen();
        int totalBalance=20000;
        int amount;
        System.out.println("\n\n\n\n\n\n");
        System.out.println(space+"--------------------------------------------------------------");
        System.out.println(space+"----                          BALANCE                        ----");
        System.out.println(space+"--------------------------------------------------------------");
        System.out.println(space+"\t\tYou have: "+totalBalance);
        System.out.println(space+"\t\t1. Input Balance");
        System.out.println(space+"\t\t2. Invest Balance");
        System.out.println(space+"\t\t3. Previous Page\n");
        System.out.println(space+"--------------------------------------------------------------");
        System.out.print(space+"\tChoose an option: ");
        int option=scanner.nextInt();
        if(option==1){
            System.out.print("\n"+space+"\tInput a balance to add: ");
            amount=scanner.nextInt();
            totalBalance+=amount;
            System.out.println(space+"\tNow you have: "+totalBalance);
        }
        else if(option==2){
            System.out.print("\n"+space+"\tInput a balance to invest: ");
            amount=scanner.nextInt();
            totalBalance-=amount;
            System.out.println(space+"\tNow you have: "+totalBalance);
        }
        else {
            familyMemberPanel("2001");
        }
    }
    public static void mindReading() throws IOException {
        clearScreen();
        System.out.println("\n\n\n\n\n\n");
        System.out.println(space+"--------------------------------------------------------------");
        System.out.println(space+"----                       MIND READING                      ----");
        System.out.println(space+"--------------------------------------------------------------");
        System.out.print(space+"\t\tEnter an word: ");
        String word=scanner.next().toLowerCase();
        if(word.equals("tired")){
            System.out.println("\n"+space+"\t\tYou have to take rest!");
        }
        else if(word.equals("sleepy")){
            System.out.println("\n"+space+"\t\tYou need to go to sleep!");
        }

        System.out.println("\n\n"+space+"--------------------------------------------------------------");
        System.out.print(space+"To go back home page click any key: ");
        scanner.next();
        familyMemberPanel("2001");


    }

    public static void familyMemberPanel(String id) throws IOException {
        clearScreen();
        System.out.println("\n\n\n\n\n\n");
        System.out.println(space+"--------------------------------------------------------------");
        System.out.println(space+"----                   How you use me                        ----");
        System.out.println(space+"--------------------------------------------------------------");

        if(k==0){
            System.out.println(space+"\t\t1.Kitchen Assistant ");
            System.out.println(space+"\t\t2.Create note");
            System.out.println(space+"\t\t3.Account section");
            System.out.println(space+"\t\t4.Mind Reading");
            System.out.println(space+"\t\t5.Previous Page");
            System.out.println(space+"--------------------------------------------------------------");
            System.out.print(space+"\tChoose an option: ");
        }
        else if(k==1){
            System.out.println(space+"\t\t2.Create note");
            System.out.println(space+"\t\t3.Account section");
            System.out.println(space+"\t\t4.Mind Reading");
            System.out.println(space+"\t\t5.Previous Page");
            System.out.println(space+"--------------------------------------------------------------");
            System.out.print(space+"\tChoose an option: ");
        }
        else if(k==2){
            System.out.println(space+"\t\t1.Kitchen Assistant ");
            System.out.println(space+"\t\t3.Account section");
            System.out.println(space+"\t\t4.Mind Reading");
            System.out.println(space+"\t\t5.Previous Page");
            System.out.println(space+"--------------------------------------------------------------");
            System.out.print(space+"\tChoose an option: ");
        }
        else if(k==3){
            System.out.println(space+"\t\t1.Kitchen Assistant ");
            System.out.println(space+"\t\t2.Create note");
            System.out.println(space+"\t\t4.Mind Reading");
            System.out.println(space+"\t\t5.Previous Page");
            System.out.println(space+"--------------------------------------------------------------");
            System.out.print(space+"\tChoose an option: ");
        }
        else if(k==4){
            System.out.println(space+"\t\t1.Kitchen Assistant ");
            System.out.println(space+"\t\t2.Create note");
            System.out.println(space+"\t\t3.Account section");
            System.out.println(space+"\t\t5.Previous Page");
            System.out.println(space+"--------------------------------------------------------------");
            System.out.print(space+"\tChoose an option: ");
        }


        int option=scanner.nextInt();
        if(option==1){
            clearScreen();
            kitchenAssistant();
        }
        else if(option==2){
            clearScreen();
            note();
        }
        else if(option==3){
            clearScreen();
            accountSection();
        }
        else if(option==4){
            clearScreen();
            mindReading();
        }
        else if(option==5){
            clearScreen();
            familyMemberSection();
        }

    }

    public static void familyMemberRegister() throws IOException {
        clearScreen();
        System.out.println("\n\n\n\n\n\n");
        System.out.println(space+"--------------------------------------------------------------");
        System.out.println(space+"----                        FAMILY                          ----");
        System.out.println(space+"--------------------------------------------------------------");

        System.out.print(space+"\t\tEnter your name: ");
        String name=scanner.next();
        System.out.print(space+"\t\tEnter your age: ");
        String age=scanner.next();
        System.out.print(space+"\t\tEnter your birthday: ");
        String birthday=scanner.next();
        System.out.print(space+"\t\tEnter your id: ");
        String id=scanner.next();
        System.out.print(space+"\t\tEnter your password: ");
        String password=scanner.next();

        Family f=new Family(name,age,birthday,password,id);
        f.savingFamily();
        section();

    }

    public static void familyMemberLogin() throws IOException {
        clearScreen();

        List<String> u=new ArrayList<>();

        Scanner scan=new Scanner(System.in);
        System.out.println("\n\n\n\n\n\n");
        System.out.println(space+"--------------------------------------------------------------");
        System.out.println(space+"----                        USER PANEL                       ----");
        System.out.println(space+"--------------------------------------------------------------");
        System.out.print("\n"+space+"\t\tEnter your id: ");
        String id=scan.next();
        System.out.print("\n"+space+"\t\tEnter your Password: ");
        String password=scan.next();
        System.out.println(space+"--------------------------------------------------------------");

        FileInputStream fi=new FileInputStream("Family.txt");
        DataInputStream DI=new DataInputStream(fi);
        Scanner scan2=new Scanner(DI);

        while(scan2.hasNextLine()){
            while(scan2.hasNextLine()){
                u.add(scan2.nextLine());
            }
        }
        fi.close();
        DI.close();

        for (int i=0;i<u.size();i=i+5){

            if(u.get(i).equals(id) && u.get(i+1).equals(password)){
                clearScreen();
                familyMemberPanel(id);
                break;
            }
            if(i>=u.size()-5) {
                System.out.println(space+"--------------------------------------------------------------");
                System.out.println(space+"\t\tnot found!\n");
                section();
            }

        }
        section();


    }
    public static void admin() throws IOException {
        clearScreen();
        System.out.println("\n\n\n\n\n\n");
        System.out.println(space+"--------------------------------------------------------------");
        System.out.println(space+"----                       ADMIN PANEL                       ----");
        System.out.println(space+"--------------------------------------------------------------");
        System.out.print(space+"\t\tEnter your id: ");
        String id=scanner.next();
        System.out.print("\n"+space+"\t\tEnter your password: ");
        String password=scanner.next();
        if(id.equals("admin") && password.equals("admin")){
            clearScreen();
            System.out.println("\n\n\n\n\n\n");
            System.out.println(space+"--------------------------------------------------------------");
            System.out.println(space+"----                       ADMIN PANEL                       ----");
            System.out.println(space+"--------------------------------------------------------------");
            System.out.println(space+"\t\tRemove any option from Family Member Panel ");
            System.out.println(space+"\t\t1.Kitchen Assistant ");
            System.out.println(space+"\t\t2.Create note");
            System.out.println(space+"\t\t3.Account section");
            System.out.println(space+"\t\t4.Mind Reading");
            System.out.println(space+"--------------------------------------------------------------");
            System.out.print(space+"Choose an option to remove , to get back all option click 0 : ");
            k=scanner.nextInt();
            System.out.println();
            System.out.println();
            section();

        }
        else{
            System.out.println(space+"--------------------------------------------------------------");
            System.out.print(space+"Wrong username or password!\n"+space+"To try again click press any key: ");
            scanner.next();
            admin();
        }
    }

    public static void allMember() throws IOException {
        clearScreen();

        List<String> s=new ArrayList<>();
        FileInputStream fi=new FileInputStream("Family.txt");
        DataInputStream DI=new DataInputStream(fi);
        Scanner output=new Scanner(DI);

        int i=0;
        System.out.println("\n\n\n\n\n\n");
        System.out.println(space+"--------------------------------------------------------------");
        System.out.println(space+"----                       ALL MEMBER                        ----");
        System.out.println(space+"--------------------------------------------------------------");
        while(output.hasNextLine()){
            s.add(output.nextLine());
            i++;
        }
        for (int j=0;j<s.size();j=j+5){
            System.out.println(space+"\t\tID       : "+s.get(j));
            System.out.println(space+"\t\tPassword : "+s.get(j+1));
            System.out.println(space+"\t\tName     : "+s.get(j+2));
            System.out.println(space+"\t\tAge      : "+s.get(j+3));
            System.out.println(space+"\t\tBirthDay : "+s.get(j+4));
            System.out.println(space+"--------------------------------------------------------------");
        }



        fi.close();
        DI.close();
        System.out.println(space+"--------------------------------------------------------------");
        System.out.print(space+"To go back previous page click any key: ");
        scanner.next();
        outsider();

    }
    public static void outsider() throws IOException {
        clearScreen();
        System.out.println("\n\n\n\n\n\n");
        System.out.println(space+"--------------------------------------------------------------");
        System.out.println(space+"----                   OUTSIDE MEMBER                        ----");
        System.out.println(space+"--------------------------------------------------------------");
        System.out.println(space+"\t\t1. Grand parents ");
        System.out.println(space+"\t\t2. Uncle or Aunty");
        System.out.println(space+"\t\t3. Previous page");
        System.out.println(space+"--------------------------------------------------------------");
        System.out.print(space+"\tChoose an option: ");
        int option=scanner.nextInt();
        if(option==1){
            clearScreen();
            System.out.println("\n\n\n\n\n\n");
            System.out.println(space+"--------------------------------------------------------------");
            System.out.println(space+"----                     GRAND PARENTS                       ----");
            System.out.println(space+"--------------------------------------------------------------");
            System.out.println(space+"\t\t1. Family Member Panel");
            System.out.println(space+"\t\t2. Member Details Section ");
            System.out.println(space+"\t\t3. Previous page");
            System.out.println(space+"--------------------------------------------------------------");
            System.out.print(space+"\tChoose an option: ");
            int option2=scanner.nextInt();
            if(option2==1){
                clearScreen();
                familyMemberPanel("2200");
            }
            else if(option2==2){
                clearScreen();
                allMember();
            }
            else if(option2==3){
                clearScreen();
                outsider();
            }
        }
        else if(option==2){
            clearScreen();
            allMember();
        }
        else if(option==3){
            clearScreen();
            firstPage();
        }
    }
    public static void familyMemberSection() throws IOException {
        clearScreen();
        System.out.println("\n\n\n\n\n\n");
        System.out.println(space+"--------------------------------------------------------------");
        System.out.println(space+"----                       ALL MEMBER                        ----");
        System.out.println(space+"--------------------------------------------------------------");
        System.out.println(space+"\t\t1. Log in");
        System.out.println(space+"\t\t2. Register");
        System.out.println(space+"\t\t3. Main page");
        System.out.println(space+"--------------------------------------------------------------");
        System.out.print(space+"\tchoose an option: ");
        int option2=scanner.nextInt();
        if(option2==1){
            clearScreen();
            familyMemberLogin();
        }
        else if(option2==2){
            clearScreen();
            familyMemberRegister();
        }
        else if(option2==3){
            clearScreen();
            firstPage();
        }
    }

    public static void firstPage() throws IOException {
        clearScreen();
        System.out.println("\t\t\t---------------------------------------------------------------------------------------------      ");
        System.out.println("\t\t\t\t\t                                      WELCOME                                  ");
        System.out.println("\t\t\t\t\t---------------------------------------------------------------------------------------------      ");
        System.out.println("\t\t\t\t\t                                                                                                     ");
        System.out.println("\t\t\t\t\t                                                                                                     ");
        System.out.println("\t\t\t\t\t   My Family buddy...............                                                                    ");
        System.out.println("\t\t\t\t\t                                                                                                     ");
        System.out.println("\t\t\t\t\t                                                                                                     ");
        System.out.println("\t\t\t\t\t                       ------------------------------------------                                    ");
        System.out.println("\t\t\t\t\t                                                       ");
        System.out.println("\t\t\t\t\t                ..........Want to..........");
        System.out.println("\t\t\t\t\t                                                                                                     ");
        System.out.println("\t\t\t                       ..........Start..........");
        System.out.println("\t\t\t\t\t                                                       ");
        System.out.println("\n");
        System.out.println(space+"--------------------------------------------------------------");
        System.out.println(space+"----                       Main Page                         ----");
        System.out.println(space+"--------------------------------------------------------------");
        System.out.println(space+"\t\t1..Admin");
        System.out.println(space+"\t\t2..Outsider Member");
        System.out.println(space+"\t\t3..Family Member");
        System.out.println(space+"--------------------------------------------------------------");
        System.out.print(space+"\tChoose an option: ");
        int option=scanner.nextInt();
        switch (option){
            case 1:
                clearScreen();
                admin();
                break;
            case 2:
                clearScreen();
                outsider();
                break;
            case 3:
                clearScreen();
                familyMemberSection();
                break;

        }
    }

    public static void main(String[] args) throws IOException {
        firstPage();

    }
}
